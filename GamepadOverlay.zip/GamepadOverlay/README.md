# Gamepad Overlay

Navegador com botões de teclado na tela (A-Z, 0-9, setas, F1-F12, Space, Enter, Shift, Ctrl, etc.)
para jogos WebAssembly. Botões movíveis, redimensionáveis e salvos automaticamente.

1. Envie estes arquivos para um repositório no GitHub.
2. Aba Actions > Build APK > aguarde terminar.
3. Baixe o APK em Artifacts (GamepadOverlay-APK), extraia o zip e instale.
