package com.example.gamepadoverlay;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MainActivity extends Activity {

    static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    // Teclas disponiveis (nome -> codigo Android)
    static final LinkedHashMap<String, Integer> KEYS = new LinkedHashMap<>();

    static {
        for (char c = 'A'; c <= 'Z'; c++) KEYS.put(String.valueOf(c), KeyEvent.KEYCODE_A + (c - 'A'));
        for (int i = 0; i <= 9; i++) KEYS.put(String.valueOf(i), KeyEvent.KEYCODE_0 + i);
        KEYS.put("UP", KeyEvent.KEYCODE_DPAD_UP);
        KEYS.put("DOWN", KeyEvent.KEYCODE_DPAD_DOWN);
        KEYS.put("LEFT", KeyEvent.KEYCODE_DPAD_LEFT);
        KEYS.put("RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT);
        KEYS.put("SPACE", KeyEvent.KEYCODE_SPACE);
        KEYS.put("ENTER", KeyEvent.KEYCODE_ENTER);
        KEYS.put("ESC", KeyEvent.KEYCODE_ESCAPE);
        KEYS.put("TAB", KeyEvent.KEYCODE_TAB);
        KEYS.put("SHIFT", KeyEvent.KEYCODE_SHIFT_LEFT);
        KEYS.put("CTRL", KeyEvent.KEYCODE_CTRL_LEFT);
        KEYS.put("ALT", KeyEvent.KEYCODE_ALT_LEFT);
        KEYS.put("BACKSPACE", KeyEvent.KEYCODE_DEL);
        KEYS.put("DELETE", KeyEvent.KEYCODE_FORWARD_DEL);
        KEYS.put("INSERT", KeyEvent.KEYCODE_INSERT);
        KEYS.put("HOME", KeyEvent.KEYCODE_MOVE_HOME);
        KEYS.put("END", KeyEvent.KEYCODE_MOVE_END);
        KEYS.put("PGUP", KeyEvent.KEYCODE_PAGE_UP);
        KEYS.put("PGDN", KeyEvent.KEYCODE_PAGE_DOWN);
        for (int i = 1; i <= 12; i++) KEYS.put("F" + i, KeyEvent.KEYCODE_F1 + (i - 1));
        KEYS.put(",", KeyEvent.KEYCODE_COMMA);
        KEYS.put(".", KeyEvent.KEYCODE_PERIOD);
        KEYS.put("-", KeyEvent.KEYCODE_MINUS);
        KEYS.put("=", KeyEvent.KEYCODE_EQUALS);
        KEYS.put(";", KeyEvent.KEYCODE_SEMICOLON);
        KEYS.put("/", KeyEvent.KEYCODE_SLASH);
        KEYS.put("[", KeyEvent.KEYCODE_LEFT_BRACKET);
        KEYS.put("]", KeyEvent.KEYCODE_RIGHT_BRACKET);
        KEYS.put("\\", KeyEvent.KEYCODE_BACKSLASH);
        KEYS.put("'", KeyEvent.KEYCODE_APOSTROPHE);
        KEYS.put("`", KeyEvent.KEYCODE_GRAVE);
    }

    static class Btn {
        String name;
        float fx, fy;
        int sizeDp;
        TextView view;
    }

    WebView web;
    FrameLayout root, layer;
    SharedPreferences sp;
    final ArrayList<Btn> btns = new ArrayList<>();
    boolean editMode = false, visible = true, desktop = false;
    float d;

    int dp(float v) {
        return Math.round(v * d);
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;
        desktop = sp.getBoolean("desktop", false);

        root = new FrameLayout(this);
        root.setKeepScreenOn(true);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        applyUA();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("http")) {
                    sp.edit().putString("url", url).apply();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Camada dos botoes: so os botoes recebem toque, o resto passa para o jogo
        layer = new FrameLayout(this);
        root.addView(layer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView mb = new TextView(this);
        mb.setText("\u2630");
        mb.setTextSize(22);
        mb.setTextColor(Color.WHITE);
        mb.setGravity(Gravity.CENTER);
        mb.setBackgroundColor(0x66000000);
        mb.setAlpha(0.7f);
        mb.setFocusable(false);
        mb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });
        root.addView(mb, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.END));

        setContentView(root);

        loadButtons();

        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int bt,
                                       int ol, int ot, int or2, int ob) {
                if ((r - l) != (or2 - ol) || (bt - t) != (ob - ot)) positionAll();
            }
        });

        String last = sp.getString("url", "");
        if (last.isEmpty()) {
            web.loadData("<html><body style='background:#111;color:#eee;font-family:sans-serif;padding:24px'>"
                    + "<h2>Gamepad Overlay</h2><p>Toque no menu (canto superior direito) e escolha Abrir site.</p>"
                    + "</body></html>", "text/html", "UTF-8");
        } else {
            web.loadUrl(last);
        }
    }

    void applyUA() {
        web.getSettings().setUserAgentString(desktop ? DESKTOP_UA : null);
    }

    // ---------- Botoes ----------

    void defaults() {
        add("UP", 0.10f, 0.42f, 56);
        add("LEFT", 0.03f, 0.60f, 56);
        add("RIGHT", 0.17f, 0.60f, 56);
        add("DOWN", 0.10f, 0.78f, 56);
        add("Z", 0.78f, 0.66f, 56);
        add("X", 0.87f, 0.54f, 56);
        add("SPACE", 0.70f, 0.80f, 56);
        add("ENTER", 0.88f, 0.78f, 56);
    }

    void loadButtons() {
        String s = sp.getString("btns", null);
        if (s == null) {
            defaults();
            return;
        }
        try {
            JSONArray a = new JSONArray(s);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String n = o.getString("n");
                if (!KEYS.containsKey(n)) continue;
                add(n, (float) o.getDouble("x"), (float) o.getDouble("y"), o.getInt("s"));
            }
        } catch (Exception e) {
            layer.removeAllViews();
            btns.clear();
            defaults();
        }
    }

    void saveButtons() {
        try {
            JSONArray a = new JSONArray();
            for (Btn k : btns) {
                JSONObject o = new JSONObject();
                o.put("n", k.name);
                o.put("x", k.fx);
                o.put("y", k.fy);
                o.put("s", k.sizeDp);
                a.put(o);
            }
            sp.edit().putString("btns", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    Btn add(String name, float fx, float fy, int sizeDp) {
        Btn k = new Btn();
        k.name = name;
        k.fx = fx;
        k.fy = fy;
        k.sizeDp = sizeDp;
        btns.add(k);

        TextView v = new TextView(this);
        v.setText(name);
        v.setTextSize(name.length() > 3 ? 10 : 16);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setPadding(0, 0, 0, 0);
        v.setFocusable(false);
        v.setFocusableInTouchMode(false);
        k.view = v;
        layer.addView(v, new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.TOP | Gravity.START));
        style(k, false);
        v.setOnTouchListener(new Touch(k));
        return k;
    }

    void positionAll() {
        int w = layer.getWidth(), h = layer.getHeight();
        if (w == 0 || h == 0) return;
        for (Btn k : btns) {
            int sz = dp(k.sizeDp);
            k.view.setX(clamp(k.fx * w, 0, w - sz));
            k.view.setY(clamp(k.fy * h, 0, h - sz));
        }
    }

    void style(Btn k, boolean pressed) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(pressed ? 0xBBFFFFFF : 0x55000000);
        g.setStroke(dp(2), editMode ? 0xFFFFD600 : 0xAAFFFFFF);
        k.view.setBackground(g);
        k.view.setTextColor(pressed ? Color.BLACK : Color.WHITE);
    }

    void refreshStyles() {
        for (Btn k : btns) style(k, false);
    }

    void press(Btn k, boolean down) {
        Integer code = KEYS.get(k.name);
        if (code == null) return;
        long t = SystemClock.uptimeMillis();
        KeyEvent ev = new KeyEvent(t, t, down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP, code, 0);
        web.requestFocus();
        web.dispatchKeyEvent(ev);
    }

    class Touch implements View.OnTouchListener {
        final Btn k;
        float ox, oy, sx, sy;
        boolean moved;

        Touch(Btn k) {
            this.k = k;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            int a = e.getActionMasked();
            if (editMode) {
                if (a == MotionEvent.ACTION_DOWN) {
                    ox = v.getX() - e.getRawX();
                    oy = v.getY() - e.getRawY();
                    sx = e.getRawX();
                    sy = e.getRawY();
                    moved = false;
                } else if (a == MotionEvent.ACTION_MOVE) {
                    if (Math.abs(e.getRawX() - sx) > dp(8) || Math.abs(e.getRawY() - sy) > dp(8)) moved = true;
                    if (moved) {
                        v.setX(clamp(e.getRawX() + ox, 0, layer.getWidth() - v.getWidth()));
                        v.setY(clamp(e.getRawY() + oy, 0, layer.getHeight() - v.getHeight()));
                    }
                } else if (a == MotionEvent.ACTION_UP) {
                    if (moved) {
                        k.fx = v.getX() / layer.getWidth();
                        k.fy = v.getY() / layer.getHeight();
                        saveButtons();
                    } else {
                        editDialog(k);
                    }
                }
                return true;
            }
            if (a == MotionEvent.ACTION_DOWN) {
                press(k, true);
                style(k, true);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                press(k, false);
                style(k, false);
            }
            return true;
        }
    }

    // ---------- Dialogos ----------

    void editDialog(final Btn k) {
        new AlertDialog.Builder(this)
                .setTitle("Botão " + k.name)
                .setItems(new String[]{"Trocar tecla", "Maior", "Menor", "Remover"},
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface dlg, int i) {
                                if (i == 0) pickKey(k);
                                else if (i == 1) resize(k, 8);
                                else if (i == 2) resize(k, -8);
                                else removeBtn(k);
                            }
                        })
                .show();
    }

    void pickKey(final Btn k) {
        final String[] names = KEYS.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Escolha a tecla")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int i) {
                        k.name = names[i];
                        k.view.setText(k.name);
                        k.view.setTextSize(k.name.length() > 3 ? 10 : 16);
                        saveButtons();
                    }
                })
                .show();
    }

    void resize(Btn k, int delta) {
        k.sizeDp = (int) clamp(k.sizeDp + delta, 32, 160);
        ViewGroup.LayoutParams lp = k.view.getLayoutParams();
        lp.width = dp(k.sizeDp);
        lp.height = dp(k.sizeDp);
        k.view.setLayoutParams(lp);
        saveButtons();
        layer.post(new Runnable() {
            @Override
            public void run() {
                positionAll();
            }
        });
    }

    void removeBtn(Btn k) {
        layer.removeView(k.view);
        btns.remove(k);
        saveButtons();
    }

    void addNew() {
        final String[] names = KEYS.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Tecla do novo botão")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int i) {
                        add(names[i], 0.45f, 0.40f, 56);
                        editMode = true;
                        refreshStyles();
                        saveButtons();
                        positionAll();
                    }
                })
                .show();
    }

    void openUrl() {
        final EditText in = new EditText(this);
        in.setSingleLine();
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        in.setText(sp.getString("url", ""));
        new AlertDialog.Builder(this)
                .setTitle("Abrir site")
                .setView(in)
                .setPositiveButton("Abrir", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        String u = in.getText().toString().trim();
                        if (u.isEmpty()) return;
                        if (!u.contains("://")) u = "https://" + u;
                        web.loadUrl(u);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    void showMenu() {
        String[] items = {
                "Abrir site (URL)",
                editMode ? "Sair do modo editar" : "Modo editar (mover / tamanho / trocar tecla)",
                "Adicionar botão",
                visible ? "Ocultar controles" : "Mostrar controles",
                "Zoom +",
                "Zoom -",
                "Modo desktop: " + (desktop ? "ligado" : "desligado"),
                "Recarregar página",
                "Restaurar botões padrão"
        };
        new AlertDialog.Builder(this)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dlg, int i) {
                        switch (i) {
                            case 0:
                                openUrl();
                                break;
                            case 1:
                                editMode = !editMode;
                                refreshStyles();
                                break;
                            case 2:
                                addNew();
                                break;
                            case 3:
                                visible = !visible;
                                layer.setVisibility(visible ? View.VISIBLE : View.GONE);
                                break;
                            case 4:
                                web.zoomIn();
                                break;
                            case 5:
                                web.zoomOut();
                                break;
                            case 6:
                                desktop = !desktop;
                                sp.edit().putBoolean("desktop", desktop).apply();
                                applyUA();
                                web.reload();
                                break;
                            case 7:
                                web.reload();
                                break;
                            case 8:
                                layer.removeAllViews();
                                btns.clear();
                                defaults();
                                saveButtons();
                                positionAll();
                                break;
                        }
                    }
                })
                .show();
    }

    // ---------- Ciclo de vida ----------

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
